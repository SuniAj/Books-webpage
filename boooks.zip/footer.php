

<div class="footer">
<p class="text-light bg-dark">Footer</p>
</div>